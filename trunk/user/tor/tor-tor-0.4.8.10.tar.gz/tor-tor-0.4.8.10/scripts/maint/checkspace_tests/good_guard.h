#ifndef GUARD_MACRO_H
#define GUARD_MACRO_H

int bar(void);

#endif
