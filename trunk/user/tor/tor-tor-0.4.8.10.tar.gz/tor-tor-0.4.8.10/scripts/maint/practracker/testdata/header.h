
// some forbidden includes
#include "foo.h"
#include "quux.h"
#include "quup.h"

// a permitted include
#include "permitted.h"
